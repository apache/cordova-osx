Android Quirks:
---------------

Watch acceleration is a little wonky right now.