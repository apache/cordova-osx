Text to Speech
==============

> Incredibly cool function that performs text-to-speech on the `String` parameter.

    phonegap.droid.textToSpeech(string);

Parameters
----------

- string (`String`) Whatever you want your little robot to say.
