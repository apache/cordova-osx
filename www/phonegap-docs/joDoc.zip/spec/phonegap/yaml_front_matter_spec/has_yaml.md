---
platforms: Android, BlackBerry, iOS
type: Function
---





PhoneGap
========

It's a fun place to be