size
==============

The size of the database in bytes.