name
============

The name of the database.