display_name
==================

The display name of the database.