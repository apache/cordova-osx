mediaError
==========

A user specified callback function that is invoked when there is an error in media functions.

    function(error) {
        // Handle the error
    }

Parameters
----------

- __error:__ The error returned by the device. (`MediaError`)
