Accelerometer
=============

> Captures device motion in the x, y, and z direction.

Methods
-------

- accelerometer.getCurrentAcceleration
- accelerometer.watchAcceleration
- accelerometer.clearWatch

Arguments
---------

- accelerometerSuccess
- accelerometerError
- accelerometerOptions

Objects (Read-Only)
-------------------

- Acceleration