accelerometerError
==================

onError callback function for acceleration functions.

    function() {
        // Handle the error
    }