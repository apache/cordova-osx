accelerometerOptions
====================

An optional parameter to customize the retrieval of the accelerometer.

Options
-------

- __frequency:__ How often to retrieve the `Acceleration` in milliseconds. _(Number)_ (Default: 10000)