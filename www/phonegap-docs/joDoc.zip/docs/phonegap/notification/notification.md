Notification
============

> Visual, audible, and tactile device notifications.

Methods
-------

- notification.alert
- notification.confirm
- notification.beep
- notification.vibrate