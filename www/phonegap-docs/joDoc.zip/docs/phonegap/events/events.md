Events
======

> PhoneGap lifecycle events.

Event Types
-----------

- backbutton
- deviceready
- menubutton
- pause
- resume
- searchbutton
- online
- offline

