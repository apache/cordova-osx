contactFields
=============

Required parameter of the `contacts.find` method.  Use this parameter to specify which fields should be included in the `Contact` objects resulting from a find operation.

    ["name", "phoneNumbers", "emails"]
