contactError
============

Error callback function for contact functions.

    function(error) {
        // Handle the error
    }