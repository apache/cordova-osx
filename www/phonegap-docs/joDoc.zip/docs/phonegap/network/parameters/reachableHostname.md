reachableHostname
=================

A `String` that specifies the remote host.

The hostname can be a domain name or a network address:

    // Valid host names
    //
    var hostname = 'phonegap.com';
    var hostname = '192.168.0.1';
    var hostname = 'localhost';
