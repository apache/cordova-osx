Network
=======

> The `network` object gives access to the device's cellular and wifi connection information.

Methods
-------

- network.isReachable

Arguments
---------

- reachableHostname
- reachableCallback
- reachableOptions

Constants
---------

- NetworkStatus
