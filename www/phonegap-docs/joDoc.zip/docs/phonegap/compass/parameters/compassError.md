compassError
============

onError callback function for compass functions.

    function() {
        // Handle the error
    }

