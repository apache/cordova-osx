compassOptions
==============

An optional parameter to customize the retrieval of the compass.

Options
-------

- __frequency:__ How often to retrieve the compass heading in milliseconds. _(Number)_ (Default: 100)