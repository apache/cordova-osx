Compass
=======

> Obtains the direction that the device is pointing.

Methods
-------

- compass.getCurrentHeading
- compass.watchHeading
- compass.clearWatch

Arguments
---------

- compassSuccess
- compassError
- compassOptions
