cameraError
===========

onError callback function that provides an error message.

    function(message) {
        // Show a helpful message
    }

Parameters
----------

- __message:__ The message is provided by the device's native code. (`String`)