Camera
======

> The `camera` object provides access to the device's default camera application.

Methods
-------

- camera.getPicture