geolocationError
================

The user's callback function that is called when there is an error for geolocation functions.

    function(error) {
        // Handle the error
    }

Parameters
----------

- __error:__ The error returned by the device. (`PositionError`)
